#ifndef SECRETS_H
#define SECRETS_H

#include "cert.h"  // Include the certificate file

// WiFi credentials
#define WIFI_SSID "PerisH"
#define WIFI_PASSWORD "@Queraina20"

// API key for the server
#define API_KEY "zPGuLlnrB9pSDKeZaH"

// Define constants for server URL and PIR sensor pin
const char* SERVER_URL = "https://smart-home-iot.angazaelimu.com/api/pirsensor_state_update";

#endif // SECRETS_H
